/* 
 * File:   %<%NAME%>%.%<%EXTENSION%>%
 * Author: %<%USER%>%
 *
 * Created on %<%DATE%>%, %<%TIME%>%
 * 
 * This file uses the CxxTest library <TestSuite> to create test cases 
 * for a students project. For full cxxtest documentation see the userguide
 * located in your C:\MinGW\cxxtest\doc or visit: 
 * http://cxxtest.com/guide.html
 * 
 */

#ifndef _TEST_AVL_TREE.H_
#define _TEST_AVL_TREE.H_

#include <cxxtest/TestSuite.h>
//Include your classes header file(s) below and uncomment.
#include "AVL_Tree.h"
#include "AVLNode.h"
#include "BST_With_Rotate.h"
#include "BTNode.h"
#include "B_Tree.h"
#include "Binary_Search_Tree.h"
#include "Binary_Tree.h"


class test_AVL_Tree : public CxxTest::TestSuite {
public:

    //All tests should start with the word 'test' followed by
    //the name of the function being tested.

    void testMyFunction() {
        //Use TS_ASSERT_EQUALS(Result, ExpResult) to test your functions. 

    }
};
#endif /* _TEST_AVL_TREE.H_ */

