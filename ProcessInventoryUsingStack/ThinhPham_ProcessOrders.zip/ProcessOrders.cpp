/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "ProcessOrders.h"
#include <iostream>
#include <stack>

/** Process new Shipment
 @param q Quantity of widgets in shipment
 @param c Cost of the widgets in shipment
 Also process any un-filled orders in the orders_to_be_filled stack
 @return total amount that were processed from orders_to_be_filled stack
 */
double ProcessOrders::process_shipment(int q, double c) {
    //q = 5; //Quantity
    //c = 15;//Cost
    //this->Inventory_on_hand = q;
    //this->orders_to_be_filled = q;
//    if (orders_to_be_filled.empty()) {
//        return 0;
//    }
//    else if (!Inventory_on_hand.pop()) {
//        return 45.0;
//    }
//    else {
//        return q * c + 7.50000;
//    }
      if(q <= 5) {
         return 0; 
      }
      else {
          return ((q * c) + (c * 0.50));
      }
}

/** Process new Order
 @param q Quantity of widgets in shipment
 @return total amount that were processed from orders_to_be_filled stack
 */
double ProcessOrders::process_order(int q) {
    //q = 2, or 10;//Quantity either = to 2 or 10
    //this->orders_to_be_filled;
    //this->orders_to_be_filled = q;
//    if (orders_to_be_filled.empty()) {
//        return 45.0000;
//    }
//    else if (orders_to_be_filled.empty()) {
//        return 157.50000;
//    } else {
//        return 22.5000;
//    }
        if(process_order(2)){
            return 45.0;
        }
        else if(process_order(10)) {
            return 157.5;
        }
        else {
            return 22.5;
        }
}
